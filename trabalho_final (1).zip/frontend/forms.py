from django import forms

class FotoForm(forms.Form):
    arquivo = forms.ImageField(label='Selecione o comprovante')