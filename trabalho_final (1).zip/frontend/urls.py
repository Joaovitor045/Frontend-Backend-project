from django.urls import path
from .views import processa_carteira, processa_login
from .views import qr, carteira, main , verifica , almoco , jantar , cafe_da_manha
from . import views

urlpatterns=[
  path('', main),
  path('carteira/', carteira, name="carteira"),
  path('qr/<str:qr_code_path>/<str:qr_txt>/', qr, name='qr'),
  path('processa_carteira/', processa_carteira, name="processa_carteira"),
  path('processa_login/', processa_login, name="processa_login"),
  path('verifica/', verifica, name="verifica"),
  path('almoco/', views.almoco, name='almoco'),
  path('jantar/', views.jantar, name='jantar'),
  path('cafe-da-manha/', views.cafe_da_manha, name='cafe_da_manha'),
]