function copyToClipboard() {
  navigator.clipboard.writeText(input.value).then(() => {
    alert('Copiado!')
  })
}