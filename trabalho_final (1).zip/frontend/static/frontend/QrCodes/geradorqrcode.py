import json
import crcmod
import qrcode

with open('shared_data.json', 'r') as f:
    data = json.load(f)
    valor = data['valor']

print(f' {valor}')


class Payload():
    def __init__(self, nome, chavepix, valor, cidade, txtId):
        self.nome = nome
        self.chavepix = chavepix
        self.valor = valor
        self.cidade = cidade
        self.txtId = txtId

        self.nome_tamanho = len(self.nome)
        self.chavepix_tamanho = len(self.chavepix)
        self.valor_tamanho = len(self.valor)
        self.cidade_tamanho = len(self.cidade)
        self.txtId_tamanho = len(self.txtId)

        self.merchantaccount_tam = f'0014BR.GOV.BCB.PIX01{self.chavepix_tamanho}{self.chavepix}'
        if self.valor_tamanho <= 9:
            self.transactionamount_tam = f'0{self.valor_tamanho}{self.valor}'
        else:
            self.transactionamount_tam = f'{self.valor_tamanho}{self.valor}'
        if self.nome_tamanho <= 9:
            self.merchantname_tam = f'0{self.nome_tamanho}{self.nome}'
        else:
            self.merchantname_tam = f'{self.nome_tamanho}{self.nome}'
        if self.cidade_tamanho <= 9:
            self.merchantcity_tam = f'0{self.cidade_tamanho}{self.cidade}'
        else:
            self.merchantcity_tam = f'{self.cidade_tamanho}{self.cidade}'
        if self.txtId_tamanho <= 9:
            self.addDatafiel_tam = f'050{self.txtId_tamanho}{self.txtId}'
        else:
            self.addDatafiel_tam = f'05{self.txtId_tamanho}{self.txtId}'

        self.payloadFormat = '000201'
        self.merchantaccount = f'26{len(self.merchantaccount_tam)}{self.merchantaccount_tam}'
        self.merchantCategCode = '52040000'
        self.transactioncurrency = '5303986'
        self.transactionamount = f'54{self.transactionamount_tam}'
        self.countryCode = '5802BR'
        self.merchantName = f'59{self.merchantname_tam}'
        self.merchantcity = f'60{self.merchantcity_tam}'
        self.addDatafiel = f'62{len(self.addDatafiel_tam)}{self.addDatafiel_tam}'
        self.crc16 = '6304'

    def gerarPayload(self):
        self.payload = f'{self.payloadFormat}{self.merchantaccount}{self.merchantCategCode}{self.transactioncurrency}{self.transactionamount}{self.countryCode}{self.merchantName}{self.merchantcity}{self.addDatafiel}{self.crc16}'
        self.gerarCrc16(self.payload)

    def gerarCrc16(self, payload):
        crc16 = crcmod.mkCrcFun(poly=0x11021, initCrc=0xFFFF, rev=False, xorOut=0x0000)
        self.crc16code = hex(crc16(str(payload).encode('utf-8')))
        self.crc16code_formatado = str(self.crc16code).replace('0x', '').upper()
        self.payload_completa = f'{payload}{self.crc16code_formatado}'
        print(self.payload_completa)
        self.gerarQrcode(self.payload_completa)

    def gerarQrcode(self, payload):      
        caminho_destino = fr'qrcode{valor}.png'
        self.qrcode = qrcode.make(payload)
        self.qrcode.save(caminho_destino)


if __name__ == "__main__":
    nome = 'Arthur'
    chavepix = 'arthurgomesadr@gmail.com'
    valor_qr = valor
    cidade = 'brasilia'
    txtId = 'LOJA01'
    p = Payload(nome, chavepix, valor, cidade, txtId)
    p.gerarPayload()

    