import json
import os
from django.shortcuts import render, HttpResponse, redirect
from django.conf import settings
import crcmod
import qrcode
from .forms import FotoForm
import pytesseract
import cv2
import re
import os
import numpy
from datetime import datetime


# Create your views here.
def main(request):
  return render(request, "index.html")

def carteira(request):
  return render(request, "carteira.html")

def qr(request, qr_code_path=None, qr_txt=None):
    context = {
        'qr_code_path': qr_code_path,
        'qr_txt': qr_txt
    }
    return render(request, "qr.html", context)



def verifica(request):
    saldo = 0.00
    data_file_path = os.path.join(settings.BASE_DIR, 'shared_data.json')

    # Carregar o saldo atual do arquivo JSON
    if os.path.exists(data_file_path):
        with open(data_file_path, 'r') as f:
            data = json.load(f)
            saldo = data.get('saldo', 0.00)

    if request.method == 'POST':
        form = FotoForm(request.POST, request.FILES)
        if form.is_valid():
            imagem = request.FILES['arquivo']

            # Carrega a imagem usando OpenCV
            imagem_comprovante = cv2.imdecode(numpy.fromstring(imagem.read(), numpy.uint8), cv2.IMREAD_UNCHANGED)

            # Configura o caminho para o tesseract
            caminho_tesseract = fr'C:\Program Files\Tesseract-OCR'
            pytesseract.pytesseract.tesseract_cmd = os.path.join(caminho_tesseract, 'tesseract.exe')

            # Extrai texto do comprovante
            texto_comprovante = pytesseract.image_to_string(imagem_comprovante)

            # Padrão regex para encontrar valores monetários
            pattern_valor = r'R\$|(?<=\s)RS|^RS'

            valor_encontrado = False
            valor_bruto = None

            # Obtém o valor armazenado anteriormente na função processa_carteira
            with open(data_file_path, 'r') as f:
                data = json.load(f)
                valor_colocado = data.get('valor', 0.00)
            valor_colocado_formatado = valor_colocado.replace('.', ',')

            # Procura valores monetários no texto do comprovante
            for line in texto_comprovante.split('\n'):
                match = re.search(pattern_valor, line)
                if match:
                    valor = line[match.start():]
                    valor_bruto = re.sub(r'[^\d,]', '', valor)  # Remove caracteres não numéricos
                    print(f"Valor encontrado no comprovante: {valor_bruto}")

                    # Comparação com o valor armazenado
                    if valor_bruto == valor_colocado_formatado:
                        valor_encontrado = True
                        # Atualiza o saldo
                        saldo += float(valor_colocado.replace(',', '.'))
                        data['saldo'] = saldo
                        with open(data_file_path, 'w') as f:
                            json.dump(data, f)
                    break  # Interrompe o loop após encontrar o valor

            # Exemplo de como você poderia retornar o resultado para o usuário
            if valor_encontrado:
                return render(request, 'carteira.html', {'saldo': saldo})
            else:
                print(f"Valor encontrado no comprovante: {valor_bruto}")  # Imprime valor para depuração
                return render(request, 'resultado.html', {'mensagem': 'Valor não encontrado ou não corresponde.', 'saldo': saldo})
    else:
        form = FotoForm()

    return render(request, 'verifica.html', {'form': form, 'saldo': saldo})



def processa_carteira(request):
    if request.method == 'POST':
        valor = request.POST.get('valor')
        senha_carteira = request.POST.get('senha_carteira')

        data_file_path = os.path.join(settings.BASE_DIR, 'shared_data.json')
        with open(data_file_path, 'w') as f:
            json.dump({'valor': valor}, f)

        class Payload:
            def __init__(self, nome, chavepix, valor, cidade, txtId):
                self.nome = nome
                self.chavepix = chavepix
                self.valor = valor
                self.cidade = cidade
                self.txtId = txtId

                self.nome_tamanho = len(self.nome)
                self.chavepix_tamanho = len(self.chavepix)
                self.valor_tamanho = len(self.valor)
                self.cidade_tamanho = len(self.cidade)
                self.txtId_tamanho = len(self.txtId)


                self.merchantaccount_tam = f'0014BR.GOV.BCB.PIX01{len(chavepix)}{chavepix}'
                if self.valor_tamanho <= 9:
                       self.transactionamount_tam = f'0{self.valor_tamanho}{self.valor}'
                else:
                    self.transactionamount_tam = f'{self.valor_tamanho}{self.valor}'
                if self.nome_tamanho <= 9:
                    self.merchantname_tam = f'0{self.nome_tamanho}{self.nome}'
                else:
                    self.merchantname_tam = f'{self.nome_tamanho}{self.nome}'
                if self.cidade_tamanho <= 9:
                    self.merchantcity_tam = f'0{self.cidade_tamanho}{self.cidade}'
                else:
                    self.merchantcity_tam = f'{self.cidade_tamanho}{self.cidade}'
                if self.txtId_tamanho <= 9:
                    self.addDatafiel_tam = f'050{self.txtId_tamanho}{self.txtId}'
                else:
                    self.addDatafiel_tam = f'05{self.txtId_tamanho}{self.txtId}'
                       
                self.payloadFormat = '000201'
                self.merchantaccount = f'26{len(self.merchantaccount_tam)}{self.merchantaccount_tam}'
                self.merchantCategCode = '52040000'
                self.transactioncurrency = '5303986'
                self.transactionamount = f'54{self.transactionamount_tam}'
                self.countryCode = '5802BR'
                self.merchantName = f'59{self.merchantname_tam}'
                self.merchantcity = f'60{self.merchantcity_tam}'
                self.addDatafiel = f'62{len(self.addDatafiel_tam)}{self.addDatafiel_tam}'
                self.crc16 = '6304'

            def gerarPayload(self):
                self.payload = f'{self.payloadFormat}{self.merchantaccount}{self.merchantCategCode}{self.transactioncurrency}{self.transactionamount}{self.countryCode}{self.merchantName}{self.merchantcity}{self.addDatafiel}{self.crc16}'
                self.gerarCrc16(self.payload)

            def gerarCrc16(self, payload):
                crc16 = crcmod.mkCrcFun(poly=0x11021, initCrc=0xFFFF, rev=False, xorOut=0x0000)
                crc16code = hex(crc16(str(payload).encode('utf-8')))
                crc16code_formatado = crc16code.replace('0x', '').upper()
                self.payload_completa = f'{payload}{crc16code_formatado}'
                self.gerarQrcode(self.payload_completa)

            def gerarQrcode(self, payload):
                relative_path = f'frontend/imgqr/qrcode{self.valor}.png'
                caminho_destino = os.path.join(settings.BASE_DIR, 'frontend/static', relative_path)
                qr_code = qrcode.make(payload)
                qr_code.save(caminho_destino)
                return relative_path

        nome = 'Arthur'
        chavepix = 'arthurgomesadr@gmail.com'
        cidade = 'brasilia'
        txtId = 'LOJA01'
        p = Payload(nome, chavepix, valor, cidade, txtId)
        p.gerarPayload()
        qr_code_path = p.gerarQrcode(p.payload_completa)
        qr_txt = str(p.payload_completa)

        context = {
            'qr_code_path': qr_code_path,
            'qr_txt': qr_txt
        }

        return render(request, 'qr.html', context)

        nome = 'Arthur'
        chavepix = 'arthurgomesadr@gmail.com'
        cidade = 'brasilia'
        txtId = 'LOJA01'
        valor = str(valor)
        p = Payload(nome, chavepix, valor, cidade, txtId)
        p.gerarPayload()
        qr_code_path = p.gerarQrcode(p.payload_completa)
        qr_txt = str(p.payload_completa)

        context = {
            'qr_code_path': qr_code_path,
            'qr_txt': qr_txt
        }

        return render(request, 'qr.html', context)

def processa_login(request):
    if request.method == 'POST':
        matricula = request.POST.get('matricula')
        senha_login = request.POST.get('senha_login')

        data_file_path = os.path.join(settings.BASE_DIR, 'shared_data.json')

        with open(os.path.join('frontend', 'static', 'frontend', 'QrCodes', 'shared_data.json'), 'w') as f:
            json.dump({'matricula': matricula, 'senha_login': senha_login}, f)

        def verificar_login(matricula, senha_login):
            try:
                with open("dados_login.txt", "r") as arquivo:
                    for linha in arquivo:
                        print(f"Linha lida: {linha.strip()}")
                        matricula_salva, senha_salva = linha.strip().split(", ")
                        matricula_salva = matricula_salva.split(": ")[1]
                        senha_salva = senha_salva.split(": ")[1]
                        print(f"Comparando matricula: {matricula} == {matricula_salva} e senha: {senha_login} == {senha_salva}")
                        if matricula == matricula_salva and senha_login == senha_salva:
                            return True
            except FileNotFoundError:
                print("Arquivo de dados de login não encontrado.")
            except Exception as e:
                print(f"Erro ao verificar login: {e}")
            return False  # Se não encontrou ou deu erro, retorna False

        if verificar_login(matricula, senha_login):
            print("Login bem-sucedido!")
            return redirect('carteira')
        else:
            print("Matrícula ou senha incorretas.")
            return HttpResponse("Matrícula ou senha incorretas.")

    return HttpResponse("Método não permitido.", status=405)

def almoco(request):
    current_date = datetime.now()
    matricula = request.session.get('matricula', 'Não disponível')
    return render(request, 'almoco.html', {'current_date': current_date})

def jantar(request):
    current_date = datetime.now()
    return render(request, 'jantar.html', {'current_date': current_date})

def cafe_da_manha(request):
    current_date = datetime.now()
    return render(request, 'cafe_da_manha.html', {'current_date': current_date})


